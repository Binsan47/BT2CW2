package com.example.bt2cw2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id= item.getItemId();

        if (id == R.id.home){

            Intent intent= new Intent(HomeActivity.this, HomeActivity.class);
            startActivity(intent);

            return true;
        }
        else
        if (id == R.id.gallery){

            Intent intent= new Intent(HomeActivity.this, GalleryActivity.class);
            startActivity(intent);

            return true;
        }
        else
        if (id == R.id.setting){

            Intent intent= new Intent(HomeActivity.this, SettingActivity.class);
            startActivity(intent);

            return true;
        }
        else
        if (id == R.id.logout){

            Intent intent= new Intent(HomeActivity.this, MainActivity.class);
            startActivity(intent);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}